---
layout: post
title: Planned Maintenance
published: true
date: 2021-02-24 19:45
---
I am planning on conducting maintenance on the physical machine that holds the Nextcloud VM.
Part of this maintenance includes swapping in a new hard-disk to allow for more growth.
I expect that the service will be down for an entire day, but I am hopeful that it will be shorter.

I will begin 02-25-21 around 13:00.
