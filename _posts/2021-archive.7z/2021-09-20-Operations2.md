---
layout: post
title: Operations Update
published: true
date: 2021-09-20 13:45
---
Moving the Minecraft server container from "HP-PVE" to "WarRig-PVE" is complete.
