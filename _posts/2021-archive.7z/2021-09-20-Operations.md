---
layout: post
title: Operations Update
published: true
date: 2021-09-20 13:40
---
To try and alleviate some issues with the Minecraft server, I'm moving it from "HP-PVE" to "WarRig-PVE" to give it more resources.
This should be done within an hour. 
